
module.exports = require('supertest');